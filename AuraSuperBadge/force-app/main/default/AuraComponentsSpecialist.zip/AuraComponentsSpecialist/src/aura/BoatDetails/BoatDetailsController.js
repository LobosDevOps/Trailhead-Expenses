({
    init: function (component, event, helper) {
        component.set("v.enableFullDetails", $A.get("e.force:navigateToSObject"));
    },
    onBoatSelected: function (component, event, helper) {
        var boatSelected = event.getParam("boat");
        console.log(boatSelected);
        component.set("v.id", boatSelected.Id);
        component.find("service").reloadRecord();

    },
    onRecordUpdated: function (component, event, helper) {
        var eventParams = event.getParams();
        if (eventParams.changeType === "LOADED") {
            // record is loaded (render other component which needs record data value)
            console.log("Record is loaded successfully.");
            console.log("You loaded a record in ");
        } else if (eventParams.changeType === "CHANGED") {
            // record is changed
        } else if (eventParams.changeType === "REMOVED") {
            // record is deleted
        } else if (eventParams.changeType === "ERROR") {
            // there’s an error while loading, saving, or deleting the record
        }
    },
    onBoatReviewAdded: function (component, event, helper) {
        console.log("Event received");
        component.find("details").set("v.selectedTabId", 'boatreviewtab');
        var BRcmp = component.find("BRcmp");
        console.log(BRcmp);
        var auraMethodResult = BRcmp.refresh();
    },
})