declare module "@salesforce/apex/BoatReviews.getAll" {
  export default function getAll(param: {boatId: any}): Promise<any>;
}
