declare module "@salesforce/apex/BoatSearchResults.getboattypes" {
  export default function getboattypes(): Promise<any>;
}
declare module "@salesforce/apex/BoatSearchResults.getBoats" {
  export default function getBoats(param: {boatTypeId: any}): Promise<any>;
}
